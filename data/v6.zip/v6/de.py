import cv2
import numpy as np
import mediapipe as mp
import tensorflow as tf
import json
import os
from collections import deque

# ==========================================
# 1. Configuration & Settings
# ==========================================
MODEL_PATH = 'best_augmented_model.keras'
LABEL_PATH = 'label_map (2).json'  # تأكد أن الاسم يطابق ملفك
SEQUENCE_LENGTH = 50  # عدد الفريمات التي تدرب عليها الموديل
CONFIDENCE_THRESHOLD = 0.75 # لن يظهر الكلمة إلا لو الثقة أعلى من 75%

# Colors for UI
COLOR_BG = (30, 30, 30)
COLOR_TEXT = (255, 255, 255)
COLOR_BAR_HIGH = (0, 255, 0)  # Green
COLOR_BAR_LOW = (0, 0, 255)   # Red

# ==========================================
# 2. V3 Preprocessing Logic (Must Match Training)
# ==========================================
mp_holistic = mp.solutions.holistic
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

def extract_features_v3(results):
    """
    Extracts and normalizes features exactly as done during training (V3 Logic).
    """
    feat = np.zeros(198, dtype=np.float32)
    
    # --- 1. Pose Normalization (Torso-Centric) ---
    torso_center = np.array([0.5, 0.5], dtype=np.float32)
    torso_scale = 1.0
    
    if results.pose_landmarks:
        ps = results.pose_landmarks.landmark
        # Calculate Center (Midpoint of shoulders and hips)
        sh_mid = (np.array([ps[11].x, ps[11].y]) + np.array([ps[12].x, ps[12].y])) / 2
        hip_mid = (np.array([ps[23].x, ps[23].y]) + np.array([ps[24].x, ps[24].y])) / 2
        torso_center = (sh_mid + hip_mid) / 2
        
        # Calculate Scale (Max distance in torso)
        shoulders_dist = np.linalg.norm(np.array([ps[11].x, ps[11].y]) - np.array([ps[12].x, ps[12].y]))
        torso_scale = max(shoulders_dist, 1e-6)
        
        # Normalize Pose Points
        pose_xy = np.array([[lm.x, lm.y] for lm in ps]).flatten()
        feat[0:66] = (pose_xy - np.tile(torso_center, 33).flatten()) / torso_scale

    # --- 2. Hand Normalization (Wrist-Relative) ---
    def process_hand(landmarks, start_idx):
        pts = np.array([[lm.x, lm.y, lm.z] for lm in landmarks.landmark])
        wrist = pts[0]
        
        # Scale based on hand size (wrist to middle finger)
        scale = np.linalg.norm(pts[9] - wrist)
        if scale < 1e-6: scale = 1.0
        
        # Normalize shape (relative to wrist)
        normalized = (pts - wrist) / scale
        feat[start_idx : start_idx+63] = normalized.flatten()
        
        # Add global wrist position (relative to torso)
        wrist_rel = (wrist[:2] - torso_center) / torso_scale
        feat[start_idx+63 : start_idx+65] = wrist_rel
        feat[start_idx+65] = wrist[2] / torso_scale # Z-coordinate scaled

    if results.left_hand_landmarks:
        process_hand(results.left_hand_landmarks, 66)
        
    if results.right_hand_landmarks:
        process_hand(results.right_hand_landmarks, 132)
    
    return feat

# ==========================================
# 3. Load Resources
# ==========================================
print(">>> ⏳ Loading Model...")
try:
    model = tf.keras.models.load_model(MODEL_PATH)
    print(">>> ✅ Model Loaded Successfully.")
except Exception as e:
    print(f">>> ❌ Error loading model: {e}")
    exit()

print(">>> ⏳ Loading Labels...")
try:
    with open(LABEL_PATH, 'r') as f:
        label_map = json.load(f)
    
    # Invert mapping to get {0: 'Hello', 1: 'World'}
    # Check format: {'word': 0} or {'0': 'word'}
    first_val = list(label_map.values())[0]
    if isinstance(first_val, int):
        actions = {v: k for k, v in label_map.items()}
    else:
        actions = {int(k): v for k, v in label_map.items()}
    print(f">>> ✅ Loaded {len(actions)} labels.")
except Exception as e:
    print(f">>> ❌ Error loading labels: {e}")
    exit()

# ==========================================
# 4. Main Loop
# ==========================================
cap = cv2.VideoCapture(0)
sequence = deque(maxlen=SEQUENCE_LENGTH)
prediction_text = "Waiting for action..."
confidence_score = 0.0

print(">>> 🎥 Starting Camera. Press 'Q' to quit.")

with mp_holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5) as holistic:
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame")
            break

        # Flip and convert
        image = cv2.flip(frame, 1)
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # MediaPipe Process
        image_rgb.flags.writeable = False
        results = holistic.process(image_rgb)
        image_rgb.flags.writeable = True
        
        # Draw Landmarks (Visual Feedback)
        mp_drawing.draw_landmarks(image, results.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS)
        mp_drawing.draw_landmarks(image, results.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS)
        
        # 1. Feature Extraction
        keypoints = extract_features_v3(results)
        sequence.append(keypoints)
        
        # 2. Prediction Logic
        if len(sequence) == SEQUENCE_LENGTH:
            # Prepare input: (1, 50, 198)
            input_data = np.expand_dims(sequence, axis=0)
            
            # Predict
            res = model.predict(input_data, verbose=0)[0]
            best_idx = np.argmax(res)
            confidence_score = res[best_idx]
            
            # Threshold Check
            if confidence_score > CONFIDENCE_THRESHOLD:
                prediction_text = actions[best_idx].upper()
            else:
                prediction_text = "..." # Low confidence

        # ==========================================
        # 5. UI Visualization
        # ==========================================
        # Top Info Bar
        cv2.rectangle(image, (0, 0), (640, 60), COLOR_BG, -1)
        
        # Confidence Bar (Dynamic Width)
        bar_width = int(confidence_score * 200)
        bar_color = COLOR_BAR_HIGH if confidence_score > CONFIDENCE_THRESHOLD else COLOR_BAR_LOW
        cv2.rectangle(image, (420, 25), (420 + bar_width, 40), bar_color, -1)
        cv2.rectangle(image, (420, 25), (620, 40), (255, 255, 255), 1) # Border
        
        # Text
        cv2.putText(image, f"SIGN: {prediction_text}", (20, 40), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1, COLOR_TEXT, 2, cv2.LINE_AA)
        
        cv2.putText(image, f"{int(confidence_score*100)}%", (360, 40), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 200), 1, cv2.LINE_AA)

        # Show Feed
        cv2.imshow('Wessal AI Engine - Live Demo', image)

        # Exit
        if cv2.waitKey(10) & 0xFF == ord('q'):
            break

cap.release()
cv2.destroyAllWindows()